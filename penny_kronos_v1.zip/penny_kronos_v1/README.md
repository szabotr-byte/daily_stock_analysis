Penny Scanner + Kronos V1 for daily_stock_analysis

Files:
- src/penny_scanner/engine.py
- src/penny_scanner/kronos_adapter.py
- src/penny_scanner/__init__.py
- tests/test_penny_scanner.py
- docs/PENNY_KRONOS_V1.md

Important:
This is a prepared V1 package. It has not been committed to GitHub because
the current GitHub connection is read-only.

Integration should reuse the existing DSA screening pipeline and providers.
Kronos stays optional so the core application does not inherit PyTorch as a
mandatory dependency.
