# Penny Scanner + Kronos V1

This package is designed for `szabotr-byte/daily_stock_analysis` v3.32.0.

## V1 logic

Hard filters:
- price: $1-$5
- market cap: <= $300M
- float: <= 30M shares
- relative volume: >= 2x
- gap: >= 3%
- premarket volume: >= 100k

Score:
- catalyst: 20%
- volume: 20%
- float: 15%
- technical setup: 15%
- Kronos confirmation: 15%
- market regime: 5%
- dilution risk: 10% penalty

Trade plan:
- entry uses the strongest available of current price, VWAP and previous-day high
- stop uses ATR
- TP1 = 1.5R
- TP2 = 2.5R
- TP3 = 4R

Kronos is optional. The normal DSA installation does not need PyTorch. When
Kronos is installed separately, `KronosAdapter` can provide `kronos_score` to
the scanner.

## DSA integration point

The cleanest integration is after the existing snapshot and daily K-line
filtering in `src/services/screening/pipeline.py`, before the final ranking.
Use the existing provider context to populate the scanner DataFrame rather
than creating a second market-data provider.

Do not enable order execution. This module only produces candidates and a
research trade plan.
