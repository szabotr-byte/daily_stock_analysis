import pandas as pd

from src.penny_scanner.engine import PennyScanner, PennyScannerConfig


def test_low_float_breakout_passes():
    df = pd.DataFrame([{
        "ticker": "TEST",
        "name": "Test Corp",
        "price": 3.20,
        "market_cap": 80_000_000,
        "float_shares": 4_000_000,
        "relative_volume": 6.0,
        "gap_pct": 12.0,
        "premarket_volume": 900_000,
        "catalyst_score": 90,
        "kronos_score": 80,
        "dilution_risk": 10,
        "market_score": 70,
        "vwap": 3.05,
        "previous_day_high": 3.10,
        "atr": 0.20,
        "price_vs_vwap_pct": 5.0,
        "ema9_above_ema20": True,
        "above_prev_day_high": True,
        "catalyst": "positive company announcement",
    }])
    result = PennyScanner(PennyScannerConfig(min_score=60)).scan(df)
    assert len(result) == 1
    assert result[0].ticker == "TEST"
    assert result[0].score >= 60
    assert result[0].stop < result[0].entry < result[0].tp2


def test_hard_filters_reject_bad_float_and_price():
    df = pd.DataFrame([{
        "ticker": "BAD",
        "price": 8.0,
        "market_cap": 80_000_000,
        "float_shares": 60_000_000,
        "relative_volume": 10,
        "gap_pct": 20,
        "premarket_volume": 2_000_000,
    }])
    assert PennyScanner().scan(df) == []
